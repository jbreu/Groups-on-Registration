# Groups on Registration

## Installation

Copy the extension to phpBB/ext/jbreu/groupsonregistration

Go to "ACP" > "Customise" > "Extensions" and enable the "Groups on Registration" extension.

## License

[GPLv2](license.txt)
